from django.shortcuts import render
from django.http import JsonResponse
import json
import base64
from django.views.decorators.csrf import csrf_exempt



def index(request):
    return render(request, 'index.html')



def is_valid_base64_string(file_b64):
    try:
        base64.b64decode(file_b64)
        return True
    except Exception:
        return False
    


@csrf_exempt
def bfhl_endpoint(request):
    if request.method == 'GET':
        return JsonResponse({"operation_code": 1})

    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({"is_success": False, "error": "Invalid JSON format"}, status=400)

        user_full_name = "john_doe"
        dob = "17091999"
        user_id = f"{user_full_name}_{dob}"

        college_email = "john@xyz.com"
        roll_number = "ABCD123"
        numbers = [x for x in data['data'] if x.isdigit()]
        alphabets = [x for x in data['data'] if x.isalpha()]
        highest_lowercase_alphabet = [max([x for x in data['data'] if x.islower()], default="")]

        file_b64 = data.get("file_b64", "")
        if file_b64 and is_valid_base64_string(file_b64):
            file_valid = True
            file_mime_type = "image/png"  
            file_size_kb = len(base64.b64decode(file_b64)) / 1024
        else:
            file_valid = False
            file_mime_type = ""
            file_size_kb = 0

        response = {
            "is_success": True,
            "user_id": user_id,
            "email": college_email,
            "roll_number": roll_number,
            "numbers": numbers,
            "alphabets": alphabets,
            "highest_lowercase_alphabet": highest_lowercase_alphabet if highest_lowercase_alphabet[0] else [],
            "file_valid": file_valid,
            "file_mime_type": file_mime_type,
            "file_size_kb": f"{file_size_kb:.2f}"
        }
        return JsonResponse(response)
